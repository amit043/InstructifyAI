
# Codex Prompt Pack — Phase 1 (Locked Scope, LS-first)

**Scope locks:**
- Phase 1 = metadata/classification curation only. **Spans/NER deferred to Phase 1.5.**
- Robust tables deferred to 1.5 (placeholders only).
- **Label Studio first**, no custom React in Phase 1.
- Connectors: **Local upload + S3/MinIO only**.

Use these prompts with your coding assistant. Replace placeholders like `<PROJECT_NAME>` and `<S3_BUCKET>`.

---

## 1) Alembic models with chunk text hash & revisioning
**Prompt:** Create SQLAlchemy models and an Alembic migration for Project, Document, Chunk, Audit, Export, ExportManifest.
Add fields: `Chunk.text_hash (char(64))`, `Chunk.rev (int, default 1)`; unique index `(doc_id, order, rev)`; functional index on `text_hash`.
Add `Document.doc_hash` (sha256) and `Document.version`.
**Accept:** `alembic upgrade head` works; same `order`+higher `rev` allowed; text_hash computed in parser pipeline.

---

## 2) Forward-migration of metadata on re-parse
**Prompt:** Implement `migrate_metadata(old_chunks, new_chunks)` to carry `metadata` forward when `text_hash` matches; if text differs, bump `rev` and do not copy.
**Accept:** Test: edit metadata → re-parse same text preserves; changed text does not.

---

## 3) Taxonomy with labeling guidelines
**Prompt:** Extend taxonomy with `helptext` and `examples[]` per field; enforce `required` fields; surface in API and LS config generator.
**Accept:** Guidelines visible in LS UI; invalid values rejected (422).

---

## 4) Label Studio config generator + webhook
**Prompt:** Generate LS XML config to show chunk text and editors for taxonomy fields. Implement webhook `POST /webhooks/label-studio` to update `chunk.metadata` and append an `Audit`.
**Accept:** Posting sample LS payload updates metadata and creates audit row.

---

## 5) Universal Chunker (token/section aware) with stable ordering
**Prompt:** Implement `chunking/chunker.py` merging parser blocks into ~1000-token chunks; preserve `section_path`/`page`; compute `text_hash` on normalized text; never cross table placeholders.
**Accept:** Deterministic order & text_hash on fixtures.

---

## 6) PDF & HTML parsers v1
**Prompt:** `parsers/pdf.py` (PyMuPDF) and `parsers/html.py` (BeautifulSoup) → emit blocks with anchors → feed chunker. Persist to `/derived/{doc_id}/chunks.jsonl`; batch insert DB. Skip OCR/tables.
**Accept:** empty_chunk_ratio < 0.1 (PDF); section_path ≥ 90% (HTML).

---

## 7) Exports + RAG preset
**Prompt:** Jinja2-based exporters. Endpoints: `POST /export/jsonl` and `/export/csv` with filters+template id. Ship built-in RAG preset: `{ "context": "<section_path>: <text>", "answer": "" }`. Write `manifest.json` (doc_ids, taxonomy_version, parser_commit, template_hash).
**Accept:** Same inputs → byte-identical outputs; RAG preset works.

---

## 8) Rule-based suggestors + Accept flow
**Prompt:** `suggestors/rules.py` for severity, step id, ticket id, datetime; return value, confidence, rationale, span. `POST /chunks/{id}/accept-suggestion` (and bulk) to copy into metadata with audit.
**Accept:** Edge-case tests pass; metadata updated & audited.

---

## 9) Curation completeness metric & gates
**Prompt:** Compute completeness for required fields; add gates to set `needs_review` when below threshold or parse metrics exceed limits. Expose `/documents/{id}/metrics`.
**Accept:** API returns completeness; docs flip status as thresholds change.

---

## 10) Project settings (engine toggles & cost guards)
**Prompt:** Add `project_settings` with `use_rules_suggestor=true`, `use_mini_llm=false`, `max_suggestions_per_doc`, `suggestion_timeout_ms`. Wire into suggestor pipeline.
**Accept:** Changing settings alters suggestion behavior on next job.

---

## 11) Scorecard CLI + CI
**Prompt:** `scripts/scorecard.py` ingests golden set, runs parse, prints: chunks_per_doc, empty_ratio, section_path_coverage, curation_completeness. Add GitHub Actions workflow to enforce thresholds.
**Accept:** CI prints metrics and fails on breach.

---

## Deferred (Phase 1.5) stubs
**Prompt:** Create flagged stubs for Logs parser, Chat parser, Table extraction, OCR, Span/NER + spaCy export. Document as out-of-scope in README.
**Accept:** Flags and README entries exist; disabled by default.
